# Infamous_Vult_Skins
### free and grandioses skinks for the VCV Rack [Vult](https://modlfo.github.io/VultModules/) modules 
## skins 
![alt text](https://raw.githubusercontent.com/infamedavid/infamous_vult_skins/master/vista.png "preview")

this is my litlle colection of skins to the  [**Vult**](https://github.com/modlfo/VultModules) modules inspired by guitar pedals.

### Installation Instructions

To install these skins Download the and  unpack the zip  chose the skins that you want use and change the skin name to the name of the vult module e.g. **"Flanme_vintage.svg"** to **"Flame.svg"** go to your vcv rack pluging folder (MacOS: Documents/Rack/ , Windows: My Documents/Rack/, Linux: ~/.Rack/ >> plugins/VultModules ) and remplace the file.

although I have the approval of **Vult** to distribute these skins, these are not part of the **Vult** software and are not maintained by **Vult.** You will have to restore them after every update. **Vult** artwork (Logo and Graphic files) are property of **Leonardo Laguna Ruiz**. please read the file [**"ARTWORK-LICENSE.txt"**](https://github.com/infamedavid/infamous_vult_skins/blob/master/ARTWORK-LICENSE.txt) for more information.

the Home of **VCV Rack** [https://vcvrack.com/](https://vcvrack.com/)

More skins are baking.
